import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'admindashboard',
    templateUrl: './admindashboard.component.html',
    styleUrls:['./admindashboard.component.css']
    
})

export class AdminDashboard implements OnInit {
    constructor() { }

    ngOnInit() { }
}